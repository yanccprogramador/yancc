
<html>
<head>
<title>atividade 3</title>
</head>
<body bgcolor="green">

<?php
  $link="rb.vfu.www";
   $b=str_split($link);
   for($i=count($b)-1;$i>=0;$i--)
     echo $b[$i];
?>   
</body>
</html>
