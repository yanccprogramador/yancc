<?php
$fp=fopen("teste.txt","a");
fwrite($fp,"bla bla bla \n \n\n\n\n\n\n\n\n\n\n\n\n\n");
fclose($fp);
?>